from distutils.core import setup

setup(
    name='CoinCollectorP5',
    version='0.1.0',
    author='Marie Erickson',
    author_email='yd7581ku@go.minneapolis.edu',
    packages=['statecoin50', ],

    url='https://www.usmint.gov/learn/coin-and-medal-programs/50-state-quarters',
    #license='LICENSE.txt',
    description='An app that helps you keep track of your 50 state quarters. A coin program by the US Mint',
    long_description=open('README.txt').read(),
    install_requires=[
        "appdirs==1.4.3",
        "branca==0.2.0",
        "Django==1.11",
        "folium==0.3.0",
        "Jinja2==2.9.6",
        "MarkupSafe==1.0",
        "packaging==16.8",
        "pyparsing==2.2.0",
        "pytz==2017.2",
        "six==1.10.0",

    ],
)
