from django.apps import AppConfig


class Statecoin50Config(AppConfig):
    name = 'statecoin50'
